﻿using System;
using System.Collections.Generic;

namespace WeatherService.Models
{
   

    public class DailyUnitsEntity
    {
        public string Time { get; set; }
        public string Sunrise { get; set; }
    }

    
}
