﻿namespace WeatherService.Models
{
    public class CityHeader
    {
        public List<City> Results { get; set; }
        public double GenerationtimeMs { get; set; }
    }
}
